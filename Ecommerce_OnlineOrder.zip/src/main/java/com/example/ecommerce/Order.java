package com.example.ecommerce;

public class Order {
    public void createOrder() {
        System.out.println("Order created.");
    }

    public void cancelOrder() {
        System.out.println("Order cancelled.");
    }
}
