package com.example.ecommerce;

public class Product {
    public void addProduct() {
        System.out.println("Product added.");
    }

    public void listProducts() {
        System.out.println("Listing all products.");
    }
}
