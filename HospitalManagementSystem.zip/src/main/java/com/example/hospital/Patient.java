package com.example.hospital;

public class Patient {
    public void registerPatient() {
        System.out.println("Patient registered.");
    }

    public void getPatientDetails() {
        System.out.println("Patient details fetched.");
    }
}
