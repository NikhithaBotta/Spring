package com.example.hospital;

public class HospitalService {
    private Patient patient;
    private Appointment appointment;
    private Billing billing;

    // setters
    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public void setAppointment(Appointment appointment) {
        this.appointment = appointment;
    }

    public void setBilling(Billing billing) {
        this.billing = billing;
    }

    public void operate() {
        patient.registerPatient();
        appointment.bookAppointment();
        billing.generateBill();
    }
}
